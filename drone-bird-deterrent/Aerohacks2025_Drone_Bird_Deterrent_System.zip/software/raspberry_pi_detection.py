#!/usr/bin/env python3
"""
Raspberry Pi Bird Detection System
Aerohacks 2025 - Drone Bird Deterrent System
"""

import cv2
import numpy as np
import tensorflow as tf
import json
import serial
import time

class BirdDetectionSystem:
    def __init__(self):
        self.camera = None
        self.interpreter = None
        self.esp32_serial = None
        self.confidence_threshold = 0.6
        self.detection_classes = {
            0: "unknown", 1: "eagle", 2: "hawk", 
            3: "crow", 4: "pigeon", 5: "sparrow"
        }
        
    def initialize_camera(self):
        self.camera = cv2.VideoCapture(0)
        self.camera.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        self.camera.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        return self.camera.isOpened()
    
    def initialize_ai_model(self):
        try:
            self.interpreter = tf.lite.Interpreter("bird_detection_model.tflite")
            self.interpreter.allocate_tensors()
            return True
        except Exception as e:
            print(f"Model initialization failed: {e}")
            return False
    
    def detect_birds(self, frame):
        # Preprocess frame for AI model
        input_details = self.interpreter.get_input_details()
        input_shape = input_details[0]['shape']
        
        resized = cv2.resize(frame, (input_shape[2], input_shape[1]))
        normalized = resized.astype(np.float32) / 255.0
        input_data = np.expand_dims(normalized, axis=0)
        
        # Run inference
        self.interpreter.set_tensor(input_details[0]['index'], input_data)
        self.interpreter.invoke()
        
        # Get results
        output_details = self.interpreter.get_output_details()
        boxes = self.interpreter.get_tensor(output_details[0]['index'])[0]
        classes = self.interpreter.get_tensor(output_details[1]['index'])[0]
        scores = self.interpreter.get_tensor(output_details[2]['index'])[0]
        
        return self.process_detections(boxes, classes, scores, frame.shape)
    
    def process_detections(self, boxes, classes, scores, frame_shape):
        detections = []
        height, width = frame_shape[:2]
        
        for i in range(len(scores)):
            if scores[i] > self.confidence_threshold:
                # Calculate bounding box
                y1, x1, y2, x2 = boxes[i] * [height, width, height, width]
                box_width = x2 - x1
                
                # Estimate distance
                distance = self.estimate_distance(box_width, int(classes[i]))
                
                detection = {
                    'class_id': int(classes[i]),
                    'class_name': self.detection_classes.get(int(classes[i]), 'unknown'),
                    'confidence': float(scores[i]),
                    'distance': distance,
                    'bbox': [int(x1), int(y1), int(x2), int(y2)]
                }
                detections.append(detection)
        
        return detections
    
    def estimate_distance(self, box_width, class_id):
        # Bird wingspan estimates in cm
        bird_sizes = {1: 200, 2: 120, 3: 90, 4: 60, 5: 25}
        focal_length = 500  # Camera focal length in pixels
        real_size = bird_sizes.get(class_id, 60)
        
        if box_width > 0:
            distance = (real_size * focal_length) / box_width
            return min(max(distance, 10), 1000)  # Clamp between 10cm and 10m
        return 500
    
    def send_detection_data(self, detections):
        if not self.esp32_serial:
            return
        
        try:
            if detections:
                # Select highest threat detection
                primary = max(detections, key=lambda x: x['confidence'])
                data = {
                    'detected': True,
                    'confidence': int(primary['confidence'] * 100),
                    'distance': primary['distance'],
                    'species': primary['class_id']
                }
            else:
                data = {
                    'detected': False,
                    'confidence': 0,
                    'distance': 0,
                    'species': 0
                }
            
            json_data = json.dumps(data) + '\n'
            self.esp32_serial.write(json_data.encode())
            
        except Exception as e:
            print(f"Communication error: {e}")
    
    def run_detection_loop(self):
        print("Starting bird detection system...")
        
        while True:
            try:
                ret, frame = self.camera.read()
                if ret:
                    detections = self.detect_birds(frame)
                    self.send_detection_data(detections)
                    
                    if detections:
                        print(f"Detected {len(detections)} birds")
                
                time.sleep(0.1)  # 10Hz detection rate
                
            except Exception as e:
                print(f"Detection loop error: {e}")
                time.sleep(1)

if __name__ == "__main__":
    detector = BirdDetectionSystem()
    
    if detector.initialize_camera() and detector.initialize_ai_model():
        print("Bird detection system initialized successfully")
        detector.run_detection_loop()
    else:
        print("Failed to initialize bird detection system")
