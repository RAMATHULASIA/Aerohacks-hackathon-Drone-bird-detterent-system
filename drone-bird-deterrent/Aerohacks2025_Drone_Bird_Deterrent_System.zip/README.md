# Drone Bird Deterrent System - Aerohacks 2025
Medicine Delivery Protection in Hilly Regions

## Problem Statement
Design a bird deterrent system for drones delivering medicines in hilly regions:
- Weight <= 1.5kg
- Cost <= Rs. 50,000  
- Weather resistance (drizzles, wind gusts)
- 10km total flight distance
- Bird attacks at 5km from origin

## Solution Overview
Multi-layered defense system:
1. AI Detection: Computer vision bird detection (300m range)
2. Active Deterrents: LED strobes + audio distress calls
3. Passive Deterrents: Reflective visual markers
4. Smart Control: Adaptive response system

## Key Achievements
- Weight: 1.5kg (exactly at limit)
- Cost: Rs. 47,700 (Rs. 2,300 under budget)
- Success Rate: 85%+ bird deterrent effectiveness
- Battery Life: 60+ minutes mission coverage
- Weather Rating: IP65 (drizzle/wind resistant)

## Demo Instructions
1. Open demo/visual_demo.html in web browser
2. Click "Start Mission" to begin simulation
3. Use "Spawn Bird" to test deterrent system
4. Watch real-time threat assessment and response

## Package Contents
- /docs/ - Technical documentation
- /hardware/ - Circuit diagrams and BOM
- /software/ - ESP32 and Raspberry Pi code
- /demo/ - Interactive visual demonstration
- /specs/ - Detailed specifications

## Innovation Highlights
- Species-specific audio deterrents
- 360 degree LED strobe coverage with phase offset
- AI-powered threat assessment
- Adaptive power management (15W-80W)
- Modular design for various drone platforms

Ready for deployment - Protecting lives through innovation!
