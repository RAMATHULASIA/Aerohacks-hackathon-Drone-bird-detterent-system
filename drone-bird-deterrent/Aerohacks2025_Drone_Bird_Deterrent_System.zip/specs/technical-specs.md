# Technical Specifications

## System Architecture
Weight: 1.5kg exactly
Cost: Rs. 47,700 (under Rs. 50,000 budget)
Power: 15W standby, 35W alert, 80W active
Battery: 3000mAh LiPo, 60+ minutes operation

## Components
Detection System (Rs. 13,500):
- Raspberry Pi 4B (4GB): AI processing
- Camera Module 3 (12MP): Bird detection
- MPU-6050: Motion sensing
- NEO-8M: GPS positioning
- BMP280: Environmental monitoring

Deterrent System (Rs. 14,800):
- 4x CREE XM-L2 LEDs: High-intensity strobes
- TPA3116D2 Amplifier: 20W audio system
- Weatherproof Speaker: Species-specific calls
- Reflective Markers: Passive visual deterrents

Control System (Rs. 8,800):
- ESP32-S3: Main microcontroller
- 3S LiPo Battery: 3000mAh power source
- Power Management: Multi-rail distribution
- LoRa Module: Long-range communication

## Performance Metrics
- Detection Range: 300m effective radius
- Response Time: <500ms from detection to activation
- Success Rate: 85%+ bird deterrent effectiveness
- Weather Rating: IP65 (drizzle and wind resistant)
- Operating Temperature: -10C to +50C
